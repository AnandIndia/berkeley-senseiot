/**
 * Berkeley SenseIoT - Frontend Application Logic
 */

// Application State Store
const state = {
  currentView: 'dashboard',
  assets: [],
  gateways: [],
  alarms: [],
  sensors: [],
  facilioConfig: {},
  facilioLogs: [],
  customFields: [],
  stateflows: [],
  users: [],
  simulator: { running: true },
  selectedTrendAssetId: null,
  selectedTrendTimeframe: '24h',
  mobileActiveTab: 'home',
  theme: localStorage.getItem('senseiot_theme') || 'dark'
};

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  setupNavigation();
  setupLiveClock();
  setupEventListeners();
  loadInitialData();

  // Polling loop for real-time telemetry updates
  setInterval(() => {
    fetchOverviewData();
  }, 2500);
});

// --- Theme Management ---
function initTheme() {
  document.documentElement.setAttribute('data-theme', state.theme);
  updateThemeIcon();
}

function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', state.theme);
  localStorage.setItem('senseiot_theme', state.theme);
  updateThemeIcon();
  if (state.currentView === 'dashboard') renderTelemetryChart();
}

function updateThemeIcon() {
  const icon = document.getElementById('themeIcon');
  if (icon) {
    icon.setAttribute('data-lucide', state.theme === 'dark' ? 'sun' : 'moon');
    if (window.lucide) lucide.createIcons();
  }
}

// --- Navigation & Views ---
function setupNavigation() {
  const navItems = document.querySelectorAll('.sidebar-nav .nav-item');
  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const view = item.getAttribute('data-view');
      switchView(view);
    });
  });

  const btnMobile = document.getElementById('btnOpenMobileView');
  if (btnMobile) {
    btnMobile.addEventListener('click', () => {
      openMobileSimulator();
    });
  }

  const btnTheme = document.getElementById('btnToggleTheme');
  if (btnTheme) btnTheme.addEventListener('click', toggleTheme);

  const btnHeaderAction = document.getElementById('btnHeaderAction');
  if (btnHeaderAction) {
    btnHeaderAction.addEventListener('click', () => {
      if (state.currentView === 'gateways') openAddGatewayModal();
      else openAddAssetModal();
    });
  }
}

function switchView(viewName) {
  state.currentView = viewName;

  // Update Nav links
  document.querySelectorAll('.sidebar-nav .nav-item').forEach(el => {
    if (el.getAttribute('data-view') === viewName) el.classList.add('active');
    else el.classList.remove('active');
  });

  // Update Pane visibility
  document.querySelectorAll('.view-pane').forEach(pane => {
    if (pane.id === `pane-${viewName}`) pane.classList.add('active');
    else pane.classList.remove('active');
  });

  // Update Header Title
  const titleMap = {
    dashboard: { title: 'Fleet Dashboard & IoT Overview', icon: 'layout-dashboard', crumb: 'Berkeley SenseIoT > Overview' },
    assets: { title: 'Asset Inventory & IoT Configuration', icon: 'boxes', crumb: 'Berkeley SenseIoT > Assets' },
    sensors: { title: 'Sensors Matrix & Live Status', icon: 'activity', crumb: 'Berkeley SenseIoT > Sensors' },
    gateways: { title: 'IoT Gateway Connection Hub', icon: 'router', crumb: 'Berkeley SenseIoT > Gateways' },
    alarms: { title: 'Alarm Center & Incident Lifecycle', icon: 'bell-ring', crumb: 'Berkeley SenseIoT > Alarms' },
    settings: { title: 'Settings, Workflows & CAFM', icon: 'sliders', crumb: 'Berkeley SenseIoT > Settings' }
  };

  const current = titleMap[viewName] || titleMap.dashboard;
  const titleEl = document.getElementById('currentViewTitle');
  const crumbEl = document.getElementById('viewBreadcrumb');
  if (titleEl) titleEl.innerHTML = `<i data-lucide="${current.icon}" class="title-icon"></i> <span>${current.title}</span>`;
  if (crumbEl) crumbEl.textContent = current.crumb;

  // Header action button label
  const headerBtn = document.getElementById('btnHeaderAction');
  if (headerBtn) {
    if (viewName === 'gateways') {
      headerBtn.innerHTML = `<i data-lucide="plus"></i> <span>Register Gateway</span>`;
    } else if (viewName === 'settings') {
      headerBtn.innerHTML = `<i data-lucide="refresh-cw"></i> <span>Sync CAFM</span>`;
    } else {
      headerBtn.innerHTML = `<i data-lucide="plus"></i> <span>Add Asset</span>`;
    }
  }

  // Refresh view contents
  if (viewName === 'assets') renderAssetsTable();
  if (viewName === 'sensors') renderSensorsTable();
  if (viewName === 'gateways') renderGatewaysTable();
  if (viewName === 'alarms') renderAlarmsTable();
  if (viewName === 'settings') renderSettings();
  if (viewName === 'dashboard') renderDashboard();

  if (window.lucide) lucide.createIcons();
}

function setupLiveClock() {
  const clockEl = document.getElementById('liveClock');
  setInterval(() => {
    if (clockEl) {
      const d = new Date();
      clockEl.textContent = d.toLocaleTimeString('en-GB') + ' UTC';
    }
  }, 1000);
}

function setupEventListeners() {
  // Asset search & filter
  const searchInput = document.getElementById('assetSearchInput');
  const catFilter = document.getElementById('assetCategoryFilter');
  if (searchInput) searchInput.addEventListener('input', renderAssetsTable);
  if (catFilter) catFilter.addEventListener('change', renderAssetsTable);

  // Sensor filter
  const sensorFilter = document.getElementById('sensorTypeFilter');
  if (sensorFilter) sensorFilter.addEventListener('change', renderSensorsTable);

  // Alarm filter
  const alarmFilter = document.getElementById('alarmSeverityFilter');
  if (alarmFilter) alarmFilter.addEventListener('change', renderAlarmsTable);

  // Trend Selectors
  const trendAssetSelect = document.getElementById('trendAssetSelect');
  const trendTimeSelect = document.getElementById('trendTimeframeSelect');
  if (trendAssetSelect) {
    trendAssetSelect.addEventListener('change', (e) => {
      state.selectedTrendAssetId = e.target.value;
      renderTelemetryChart();
    });
  }
  if (trendTimeSelect) {
    trendTimeSelect.addEventListener('change', (e) => {
      state.selectedTrendTimeframe = e.target.value;
      renderTelemetryChart();
    });
  }
}

// --- Data Fetching ---
async function loadInitialData() {
  try {
    const [assetsRes, gatewaysRes, customRes, facilioRes, stateRes] = await Promise.all([
      fetch('/api/assets').then(r => r.json()),
      fetch('/api/gateways').then(r => r.json()),
      fetch('/api/custom-fields').then(r => r.json()),
      fetch('/api/facilio/config').then(r => r.json()),
      fetch('/api/stateflows').then(r => r.json())
    ]);

    state.assets = assetsRes;
    state.gateways = gatewaysRes;
    state.customFields = customRes;
    state.facilioConfig = facilioRes;
    state.stateflows = stateRes;

    if (state.assets.length > 0 && !state.selectedTrendAssetId) {
      state.selectedTrendAssetId = state.assets[0].id;
    }

    populateTrendAssetDropdown();
    fetchOverviewData();
  } catch (err) {
    console.error('Failed loading initial data:', err);
  }
}

async function fetchOverviewData() {
  try {
    const res = await fetch('/api/overview');
    const data = await res.json();

    // Update KPI counters
    const stats = data.stats;
    document.getElementById('kpi-total-assets').textContent = stats.totalAssets;
    document.getElementById('kpi-asset-subtext').innerHTML = `
      <span style="color:#34D399;">${stats.healthyAssets} Healthy</span> &bull; 
      <span style="color:#FBBF24;">${stats.warningAssets} Warning</span> &bull; 
      <span style="color:#F87171;">${stats.criticalAssets} Critical</span>
    `;
    document.getElementById('kpi-gateways').textContent = `${stats.onlineGateways} / ${stats.totalGateways}`;
    document.getElementById('kpi-sensors').textContent = stats.totalSensors;
    document.getElementById('kpi-facilio-wo').textContent = `${stats.facilioDispatchesCount} Dispatched`;

    // Pill badges in sidebar
    document.getElementById('nav-assets-count').textContent = stats.totalAssets;
    document.getElementById('nav-gateways-count').textContent = stats.totalGateways;
    const alarmPill = document.getElementById('nav-alarms-count');
    alarmPill.textContent = stats.activeAlarmsCount;
    if (stats.activeAlarmsCount > 0) {
      alarmPill.style.display = 'inline-block';
      alarmPill.classList.add('danger');
    } else {
      alarmPill.style.display = 'none';
    }

    // Refresh state data
    state.alarms = data.activeAlarms;
    state.gateways = data.gateways;

    // Refresh active view
    if (state.currentView === 'dashboard') {
      renderDashboardAssets(data.assetsSummary);
      renderDashboardAlarms(data.activeAlarms);
      renderTelemetryChart();
    } else if (state.currentView === 'sensors') {
      renderSensorsTable();
    } else if (state.currentView === 'alarms') {
      renderAlarmsTable();
    }

    // Update mobile screen if open
    if (document.getElementById('modalMobileSimulator').classList.contains('active')) {
      updateMobileScreen();
    }

  } catch (err) {
    console.error('Error in fetchOverviewData:', err);
  }
}

// --- Dashboard Rendering ---
function populateTrendAssetDropdown() {
  const sel = document.getElementById('trendAssetSelect');
  if (!sel) return;
  sel.innerHTML = state.assets.map(a => `<option value="${a.id}">${a.name}</option>`).join('');
  if (state.selectedTrendAssetId) sel.value = state.selectedTrendAssetId;
}

function renderDashboardAssets(assetsSummary) {
  const grid = document.getElementById('dashboardAssetGrid');
  if (!grid || !assetsSummary) return;

  grid.innerHTML = assetsSummary.map(a => {
    const fullAsset = state.assets.find(item => item.id === a.id) || a;
    const gateway = state.gateways.find(g => g.id === a.gatewayId);

    const sensorsHtml = (fullAsset.sensors || []).slice(0, 3).map(s => {
      let valClass = '';
      if (s.status === 'WARNING') valClass = 'warn';
      if (s.status === 'CRITICAL') valClass = 'crit';
      return `
        <div class="sensor-row">
          <div class="sensor-name-type">
            <i data-lucide="${getSensorIcon(s.type)}" style="width:13px; height:13px;"></i>
            <span>${s.name}</span>
          </div>
          <span class="sensor-val ${valClass}">${s.currentValue} ${s.unit}</span>
        </div>
      `;
    }).join('');

    return `
      <div class="asset-card">
        <div class="asset-card-top">
          <div>
            <div class="asset-name">${a.name}</div>
            <div class="asset-meta">
              <span>${a.tag}</span> &bull; 
              <span>${a.location}</span>
            </div>
          </div>
          <span class="status-badge ${a.status}">${a.status}</span>
        </div>

        <div class="asset-sensors-list">
          ${sensorsHtml}
        </div>

        <div class="asset-card-bottom">
          <div style="font-size:0.75rem; color:var(--text-muted); display:flex; align-items:center; gap:4px;">
            <i data-lucide="router" style="width:12px; height:12px;"></i>
            <span>${gateway ? gateway.name : 'Central Gateway'}</span>
          </div>
          <div style="display:flex; gap:6px;">
            <button class="top-btn" style="padding:3px 8px; font-size:0.72rem;" onclick="inspectAsset('${a.id}')">Inspect</button>
            <button class="top-btn" style="padding:3px 8px; font-size:0.72rem;" onclick="openAddSensorModal('${a.id}')">+ Sensor</button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  if (window.lucide) lucide.createIcons();
}

function renderDashboardAlarms(alarms) {
  const container = document.getElementById('dashboardAlarmsList');
  if (!container) return;

  if (!alarms || alarms.length === 0) {
    container.innerHTML = `
      <div style="text-align:center; padding:30px 10px; color:var(--text-muted); font-size:0.85rem;">
        <i data-lucide="shield-check" style="width:32px; height:32px; color:var(--bky-green); margin-bottom:6px;"></i>
        <div>All assets operating within safe limits.</div>
        <div style="font-size:0.75rem; margin-top:4px;">No active alarms or threshold breaches.</div>
      </div>
    `;
    if (window.lucide) lucide.createIcons();
    return;
  }

  container.innerHTML = alarms.map(alm => {
    return `
      <div style="background:var(--bg-input); border-left:3px solid ${alm.severity === 'CRITICAL' ? '#F87171' : 'var(--bky-orange)'}; border-radius:var(--radius-sm); padding:10px 12px; margin-bottom:10px; font-size:0.8rem;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
          <span style="font-weight:700; color:${alm.severity === 'CRITICAL' ? '#F87171' : 'var(--bky-orange)'};">${alm.severity} ALARM</span>
          <span style="font-size:0.7rem; color:var(--text-muted);">${new Date(alm.timestamp).toLocaleTimeString()}</span>
        </div>
        <div style="color:var(--text-primary); font-weight:600; margin-bottom:2px;">${alm.assetName}</div>
        <div style="color:var(--text-secondary); font-size:0.75rem; margin-bottom:8px;">${alm.message}</div>
        <div style="display:flex; justify-content:flex-end; gap:6px;">
          <button class="top-btn" style="padding:2px 7px; font-size:0.7rem;" onclick="acknowledgeAlarm('${alm.id}')">Acknowledge</button>
          ${!alm.facilioTicketId ? `<button class="top-btn primary" style="padding:2px 7px; font-size:0.7rem;" onclick="dispatchAlarmToFacilio('${alm.id}')">Dispatch Facilio WO</button>` : `<span style="font-size:0.7rem; color:#60A5FA; font-weight:700;">${alm.facilioTicketId}</span>`}
        </div>
      </div>
    `;
  }).join('');

  if (window.lucide) lucide.createIcons();
}

// --- SVG Telemetry Trend Chart ---
async function renderTelemetryChart() {
  const svg = document.getElementById('dashboardTelemetrySvg');
  if (!svg) return;

  const assetId = state.selectedTrendAssetId || (state.assets[0] ? state.assets[0].id : 'AST-101');
  const timeframe = state.selectedTrendTimeframe || '24h';

  try {
    const res = await fetch(`/api/telemetry/history?assetId=${assetId}&timeframe=${timeframe}`);
    const data = await res.json();
    const history = data.results || [];
    const stats = data.stats;

    // Update stats bar
    const statsBar = document.getElementById('trendStatsBar');
    if (statsBar && stats) {
      statsBar.innerHTML = `
        <span>Mean: <strong>${stats.mean}</strong></span>
        <span>Peak: <strong>${stats.max}</strong></span>
        <span>Min: <strong>${stats.min}</strong></span>
        <span style="color:var(--bky-orange);">Data Points: <strong>${stats.count}</strong></span>
      `;
    }

    if (history.length < 2) {
      svg.innerHTML = `<text x="350" y="120" fill="var(--text-muted)" text-anchor="middle" font-size="14">Collecting live sensor telemetry...</text>`;
      return;
    }

    // Separate into lines by sensorType
    const grouped = {};
    history.forEach(pt => {
      const type = pt.sensorType || 'metric';
      if (!grouped[type]) grouped[type] = [];
      grouped[type].push(pt);
    });

    const width = 700;
    const height = 240;
    const padding = { top: 20, right: 30, bottom: 30, left: 50 };

    const allValues = history.map(h => h.value);
    let minVal = Math.min(...allValues);
    let maxVal = Math.max(...allValues);
    if (minVal === maxVal) { minVal -= 5; maxVal += 5; }
    const valRange = maxVal - minVal;

    // Build SVG paths
    const colors = ['#38BDF8', '#F4981C', '#34D399', '#F87171'];
    let pathIndex = 0;
    let pathsHtml = '';
    let legendHtml = '';

    // Draw Grid Lines
    let gridLines = '';
    for (let i = 0; i <= 4; i++) {
      const y = padding.top + (height - padding.top - padding.bottom) * (i / 4);
      const valLabel = (maxVal - (valRange * (i / 4))).toFixed(1);
      gridLines += `
        <line x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}" stroke="var(--border-color)" stroke-dasharray="3,3" />
        <text x="${padding.left - 8}" y="${y + 4}" fill="var(--text-muted)" font-size="10" text-anchor="end">${valLabel}</text>
      `;
    }

    Object.keys(grouped).forEach(sensorKey => {
      const pts = grouped[sensorKey];
      const color = colors[pathIndex % colors.length];
      pathIndex++;

      const coords = pts.map((pt, idx) => {
        const x = padding.left + (idx / (pts.length - 1)) * (width - padding.left - padding.right);
        const y = padding.top + (height - padding.top - padding.bottom) * (1 - (pt.value - minVal) / valRange);
        return `${x},${y}`;
      });

      const d = `M ` + coords.join(' L ');
      pathsHtml += `<path d="${d}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" />`;

      // Draw latest point dot
      const lastCoord = coords[coords.length - 1].split(',');
      pathsHtml += `<circle cx="${lastCoord[0]}" cy="${lastCoord[1]}" r="4" fill="${color}" stroke="#FFF" stroke-width="1.5" />`;

      legendHtml += `
        <g transform="translate(${padding.left + (pathIndex - 1) * 120}, 12)">
          <circle cx="0" cy="0" r="4" fill="${color}" />
          <text x="8" y="4" fill="var(--text-secondary)" font-size="11">${sensorKey.toUpperCase()}</text>
        </g>
      `;
    });

    svg.innerHTML = `
      ${gridLines}
      ${pathsHtml}
      ${legendHtml}
    `;

  } catch (err) {
    console.error('Error rendering telemetry chart:', err);
  }
}

// --- Assets View Rendering ---
async function renderAssetsTable() {
  const tbody = document.getElementById('assetsTableBody');
  if (!tbody) return;

  try {
    const res = await fetch('/api/assets');
    state.assets = await res.json();

    const search = (document.getElementById('assetSearchInput')?.value || '').toLowerCase();
    const cat = document.getElementById('assetCategoryFilter')?.value || 'ALL';

    const filtered = state.assets.filter(a => {
      const matchSearch = a.name.toLowerCase().includes(search) || a.tag.toLowerCase().includes(search) || a.location.toLowerCase().includes(search);
      const matchCat = cat === 'ALL' || a.category === cat;
      return matchSearch && matchCat;
    });

    tbody.innerHTML = filtered.map(a => {
      const gw = state.gateways.find(g => g.id === a.gatewayId);
      const sensorsStr = (a.sensors || []).map(s => `<span style="display:inline-block; background:var(--bg-input); padding:2px 6px; border-radius:4px; font-size:0.75rem; margin:2px;">${s.name}: <strong>${s.currentValue} ${s.unit}</strong></span>`).join(' ');

      return `
        <tr>
          <td>
            <div style="font-weight:700; color:var(--text-primary);">${a.name}</div>
            <div style="font-size:0.75rem; color:var(--text-muted); font-family:monospace;">${a.tag} &bull; ID: ${a.id}</div>
          </td>
          <td>
            <div>${a.category}</div>
            <div style="font-size:0.75rem; color:var(--text-muted);">${a.location} (${a.floor || ''})</div>
          </td>
          <td>
            <span style="font-weight:700; font-size:0.75rem; color:${a.criticality === 'CRITICAL' ? '#F87171' : (a.criticality === 'HIGH' ? 'var(--bky-orange)' : 'var(--text-secondary)')};">
              ${a.criticality}
            </span>
          </td>
          <td>
            <div>${gw ? gw.name : 'Unassigned'}</div>
            <div style="font-size:0.72rem; color:var(--text-muted);">${gw ? gw.protocol : ''}</div>
          </td>
          <td style="max-width:240px;">
            ${sensorsStr || '<span style="color:var(--text-muted); font-size:0.75rem;">No sensors</span>'}
          </td>
          <td>
            <span class="status-badge ${a.status}">${a.status}</span>
            <div style="font-size:0.72rem; color:var(--text-muted); margin-top:2px;">State: ${a.stateflowState || 'NORMAL'}</div>
          </td>
          <td>
            <div style="display:flex; gap:6px;">
              <button class="top-btn" style="padding:3px 8px; font-size:0.72rem;" onclick="openAddSensorModal('${a.id}')">+ Sensor</button>
              <button class="top-btn danger" style="padding:3px 8px; font-size:0.72rem;" onclick="deleteAsset('${a.id}')">Delete</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

  } catch (err) {
    console.error('Error rendering assets table:', err);
  }
}

// --- Sensors & Status View ---
async function renderSensorsTable() {
  const tbody = document.getElementById('sensorsTableBody');
  if (!tbody) return;

  try {
    const res = await fetch('/api/sensors/status');
    const sensors = await res.json();
    state.sensors = sensors;

    const typeFilter = document.getElementById('sensorTypeFilter')?.value || 'ALL';
    const filtered = sensors.filter(s => typeFilter === 'ALL' || s.sensorType === typeFilter);

    tbody.innerHTML = filtered.map(s => {
      let valColor = '#34D399';
      if (s.status === 'WARNING') valColor = 'var(--bky-orange)';
      if (s.status === 'CRITICAL') valColor = '#F87171';

      return `
        <tr>
          <td>
            <div style="font-weight:700; color:var(--text-primary); display:flex; align-items:center; gap:6px;">
              <i data-lucide="${getSensorIcon(s.sensorType)}" style="width:14px; height:14px; color:#60A5FA;"></i>
              <span>${s.sensorName}</span>
            </div>
            <div style="font-size:0.72rem; color:var(--text-muted); text-transform:uppercase;">${s.sensorType} (${s.unit})</div>
          </td>
          <td>
            <div style="font-weight:600;">${s.assetName}</div>
            <div style="font-size:0.72rem; color:var(--text-muted);">${s.assetTag} &bull; ${s.assetLocation}</div>
          </td>
          <td>
            <div>${s.gatewayName}</div>
          </td>
          <td>
            <div style="font-size:1.1rem; font-weight:800; color:${valColor};">${s.currentValue} ${s.unit}</div>
          </td>
          <td>
            <div style="font-size:0.78rem; color:var(--text-secondary);">High: ${s.warningHigh !== undefined ? s.warningHigh + ' ' + s.unit : '--'}</div>
            <div style="font-size:0.78rem; color:var(--text-muted);">Low: ${s.warningLow !== undefined ? s.warningLow + ' ' + s.unit : '--'}</div>
          </td>
          <td>
            <div style="font-size:0.78rem; color:#F87171; font-weight:700;">High: ${s.criticalHigh !== undefined ? s.criticalHigh + ' ' + s.unit : '--'}</div>
            <div style="font-size:0.78rem; color:#F87171;">Low: ${s.criticalLow !== undefined ? s.criticalLow + ' ' + s.unit : '--'}</div>
          </td>
          <td>
            <span class="status-badge ${s.status}">${s.status}</span>
          </td>
          <td>
            <button class="top-btn" style="padding:3px 8px; font-size:0.72rem;" onclick="promptCalibrateSensor('${s.assetId}', '${s.sensorId}')">Calibrate</button>
          </td>
        </tr>
      `;
    }).join('');

    if (window.lucide) lucide.createIcons();
  } catch (err) {
    console.error('Error rendering sensors:', err);
  }
}

// --- Gateways View ---
async function renderGatewaysTable() {
  const tbody = document.getElementById('gatewaysTableBody');
  if (!tbody) return;

  try {
    const res = await fetch('/api/gateways');
    state.gateways = await res.json();

    tbody.innerHTML = state.gateways.map(gw => {
      const connectedCount = state.assets.filter(a => a.gatewayId === gw.id).length;
      return `
        <tr>
          <td>
            <div style="font-weight:700; color:var(--text-primary);">${gw.name}</div>
            <div style="font-size:0.75rem; color:var(--text-muted);">${gw.model} &bull; ${gw.id}</div>
          </td>
          <td>
            <span style="display:inline-block; background:rgba(43,56,143,0.2); color:#60A5FA; font-weight:700; font-size:0.72rem; padding:2px 6px; border-radius:4px;">
              ${gw.protocol} (Port ${gw.port})
            </span>
          </td>
          <td>
            <div style="font-family:monospace; font-size:0.8rem;">${gw.ip}</div>
            <div style="font-size:0.7rem; color:var(--text-muted); font-family:monospace;">MAC: ${gw.mac}</div>
          </td>
          <td>
            <div style="font-family:monospace; font-size:0.75rem; color:var(--text-secondary); background:var(--bg-input); padding:2px 6px; border-radius:4px; max-width:180px; overflow:hidden; text-overflow:ellipsis;">
              ${gw.apiKey}
            </div>
          </td>
          <td>
            <div style="font-size:0.8rem; color:#34D399; font-weight:700;">${gw.packetRate} pkts/min</div>
            <div style="font-size:0.7rem; color:var(--text-muted);">${new Date(gw.lastHeartbeat).toLocaleTimeString()}</div>
          </td>
          <td>
            <span class="status-badge HEALTHY">${gw.status}</span>
            <div style="font-size:0.72rem; color:var(--text-muted); margin-top:2px;">${connectedCount} Assets Linked</div>
          </td>
          <td>
            <div style="display:flex; gap:6px;">
              <button class="top-btn" style="padding:3px 8px; font-size:0.72rem;" onclick="testPingGateway('${gw.id}')">Ping Test</button>
              <button class="top-btn danger" style="padding:3px 8px; font-size:0.72rem;" onclick="deleteGateway('${gw.id}')">Delete</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

  } catch (err) {
    console.error('Error rendering gateways table:', err);
  }
}

// --- Alarms View ---
async function renderAlarmsTable() {
  const tbody = document.getElementById('alarmsTableBody');
  if (!tbody) return;

  try {
    const res = await fetch('/api/alarms');
    state.alarms = await res.json();

    const sevFilter = document.getElementById('alarmSeverityFilter')?.value || 'ALL';
    const filtered = state.alarms.filter(a => sevFilter === 'ALL' || a.severity === sevFilter);

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted);">No active alarms found. All asset sensors operating normally.</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(alm => {
      return `
        <tr>
          <td>
            <span class="status-badge ${alm.severity === 'CRITICAL' ? 'CRITICAL' : 'WARNING'}">${alm.severity}</span>
            <div style="font-size:0.72rem; color:var(--text-muted); font-family:monospace; margin-top:2px;">${alm.id}</div>
          </td>
          <td>
            <div style="font-weight:700;">${alm.assetName}</div>
            <div style="font-size:0.72rem; color:var(--text-muted);">Asset ID: ${alm.assetId}</div>
          </td>
          <td>
            <div style="font-size:0.82rem; color:var(--text-primary);">${alm.message}</div>
          </td>
          <td>
            <span style="font-weight:800; font-size:0.95rem; color:${alm.severity === 'CRITICAL' ? '#F87171' : 'var(--bky-orange)'};">
              ${alm.triggerValue}
            </span>
            <span style="font-size:0.72rem; color:var(--text-muted); display:block;">Limit: ${alm.threshold}</span>
          </td>
          <td>
            <div style="font-size:0.78rem;">${new Date(alm.timestamp).toLocaleTimeString()}</div>
            <div style="font-size:0.7rem; color:var(--text-muted);">${new Date(alm.timestamp).toLocaleDateString()}</div>
          </td>
          <td>
            ${alm.facilioTicketId ? `
              <div style="font-weight:700; color:#60A5FA; font-size:0.8rem;">${alm.facilioTicketId}</div>
              <div style="font-size:0.7rem; color:#34D399;">Dispatched to CAFM</div>
            ` : `
              <button class="top-btn primary" style="padding:2px 8px; font-size:0.72rem;" onclick="dispatchAlarmToFacilio('${alm.id}')">
                <i data-lucide="send" style="width:11px; height:11px;"></i> Dispatch WO
              </button>
            `}
          </td>
          <td>
            <div style="display:flex; gap:6px;">
              ${alm.status === 'ACTIVE' ? `
                <button class="top-btn" style="padding:2px 7px; font-size:0.72rem;" onclick="acknowledgeAlarm('${alm.id}')">Acknowledge</button>
              ` : `<span style="font-size:0.72rem; color:var(--text-muted);">Acked</span>`}
              <button class="top-btn" style="padding:2px 7px; font-size:0.72rem; background:rgba(0,132,61,0.15); color:#34D399; border-color:rgba(0,132,61,0.3);" onclick="resolveAlarm('${alm.id}')">Resolve</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    if (window.lucide) lucide.createIcons();
  } catch (err) {
    console.error('Error rendering alarms:', err);
  }
}

// --- Settings View ---
function switchSettingsTab(tabId) {
  document.querySelectorAll('.tabs-strip .tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.settings-subtab-pane').forEach(p => p.style.display = 'none');

  const activePane = document.getElementById(tabId);
  if (activePane) activePane.style.display = 'block';

  // Highlight tab button
  event.currentTarget.classList.add('active');

  if (tabId === 'tab-stateflow') renderStateflows();
  if (tabId === 'tab-customfields') renderCustomFieldsTable();
  if (tabId === 'tab-facilio') renderFacilioLogs();
  if (tabId === 'tab-users') renderUsersTable();
}

function renderSettings() {
  renderStateflows();
  renderCustomFieldsTable();
  renderFacilioLogs();
  renderUsersTable();
}

function renderStateflows() {
  const container = document.getElementById('stateflowVisualPipeline');
  const tableBody = document.getElementById('stateflowTransitionsTable');
  if (!container || !state.stateflows[0]) return;

  const flow = state.stateflows[0];
  container.innerHTML = flow.states.map((st, idx) => `
    <div class="state-node ${idx === 0 ? 'active' : ''}">
      <div style="font-size:0.68rem; font-weight:700; color:${st.color}; text-transform:uppercase;">Stage ${idx + 1}</div>
      <div style="font-weight:700; font-size:0.85rem; color:var(--text-primary);">${st.label}</div>
      <div style="font-size:0.72rem; color:var(--text-muted);">${st.description}</div>
    </div>
    ${idx < flow.states.length - 1 ? `<div class="state-arrow">&rarr;</div>` : ''}
  `).join('');

  if (tableBody) {
    tableBody.innerHTML = flow.transitions.map(tr => `
      <tr>
        <td><span class="status-badge" style="background:rgba(255,255,255,0.06);">${tr.from}</span></td>
        <td><span class="status-badge" style="background:rgba(43,56,143,0.15); color:#60A5FA;">${tr.to}</span></td>
        <td style="font-size:0.8rem; color:var(--text-secondary);">${tr.trigger}</td>
        <td style="font-size:0.8rem; color:#34D399; font-weight:600;">${tr.autoAction}</td>
      </tr>
    `).join('');
  }
}

async function renderCustomFieldsTable() {
  const tbody = document.getElementById('customFieldsTableBody');
  if (!tbody) return;

  try {
    const res = await fetch('/api/custom-fields');
    state.customFields = await res.json();

    tbody.innerHTML = state.customFields.map(cf => `
      <tr>
        <td>
          <span style="font-weight:700; font-size:0.75rem; background:rgba(43,56,143,0.2); color:#60A5FA; padding:2px 6px; border-radius:4px;">
            ${cf.entity}
          </span>
        </td>
        <td><div style="font-weight:700;">${cf.label}</div></td>
        <td><code style="font-size:0.75rem; color:var(--bky-orange);">${cf.key}</code></td>
        <td><span style="font-size:0.8rem;">${cf.type}</span></td>
        <td><span style="font-size:0.8rem; color:${cf.required ? '#F87171' : 'var(--text-muted)'};">${cf.required ? 'Yes' : 'No'}</span></td>
        <td><span style="font-size:0.8rem; color:var(--text-muted);">${cf.defaultValue || '--'}</span></td>
        <td>
          <button class="top-btn danger" style="padding:2px 6px; font-size:0.7rem;" onclick="deleteCustomField('${cf.id}')">Delete</button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Error loading custom fields:', err);
  }
}

async function renderFacilioLogs() {
  const tbody = document.getElementById('facilioLogsTableBody');
  if (!tbody) return;

  try {
    const res = await fetch('/api/facilio/logs');
    state.facilioLogs = await res.json();

    tbody.innerHTML = state.facilioLogs.map(log => `
      <tr>
        <td><span style="font-size:0.78rem;">${new Date(log.timestamp).toLocaleString()}</span></td>
        <td><span style="font-size:0.75rem; font-weight:700; color:#60A5FA;">${log.action}</span></td>
        <td><div>${log.assetName || log.assetId}</div></td>
        <td><span style="font-weight:800; font-family:monospace; color:#34D399;">${log.facilioTicketId}</span></td>
        <td><span class="status-badge HEALTHY">${log.status}</span></td>
        <td>
          <button class="top-btn" style="padding:2px 6px; font-size:0.7rem;" onclick="inspectFacilioPayload('${log.id}')">Inspect JSON</button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Error rendering Facilio logs:', err);
  }
}

async function renderUsersTable() {
  const tbody = document.getElementById('usersTableBody');
  if (!tbody) return;

  try {
    const res = await fetch('/api/users');
    state.users = await res.json();

    tbody.innerHTML = state.users.map(u => `
      <tr>
        <td><div style="font-weight:700;">${u.name}</div></td>
        <td><div style="font-size:0.8rem; color:var(--text-secondary);">${u.email}</div></td>
        <td><div style="font-size:0.8rem;">${u.department}</div></td>
        <td>
          <span style="font-weight:700; font-size:0.75rem; background:rgba(0,132,61,0.15); color:#34D399; padding:2px 6px; border-radius:4px;">
            ${u.role}
          </span>
        </td>
        <td><span class="status-badge HEALTHY">${u.status}</span></td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Error rendering users:', err);
  }
}

// --- Action Handlers ---
async function injectFault(assetId, sensorType, value, faultName) {
  try {
    const res = await fetch('/api/simulator/inject-fault', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ assetId, sensorType, value, faultName })
    });
    const data = await res.json();
    alert(`Fault Injected: ${faultName} on ${assetId}.\nSensor reading set to ${value}. Alarm evaluated and CAFM state triggered!`);
    fetchOverviewData();
  } catch (err) {
    alert('Failed injecting fault: ' + err.message);
  }
}

async function clearFaults() {
  try {
    await fetch('/api/simulator/clear-faults', { method: 'POST' });
    alert('All telemetry faults cleared and sensor values normalized.');
    fetchOverviewData();
  } catch (err) {
    alert('Failed clearing faults: ' + err.message);
  }
}

async function acknowledgeAlarm(alarmId) {
  try {
    await fetch(`/api/alarms/${alarmId}/acknowledge`, { method: 'POST' });
    fetchOverviewData();
  } catch (err) {
    alert('Error acknowledging alarm: ' + err.message);
  }
}

async function resolveAlarm(alarmId) {
  try {
    await fetch(`/api/alarms/${alarmId}/resolve`, { method: 'POST' });
    alert('Alarm marked as Resolved. Asset state reset.');
    fetchOverviewData();
  } catch (err) {
    alert('Error resolving alarm: ' + err.message);
  }
}

async function dispatchAlarmToFacilio(alarmId) {
  try {
    const res = await fetch(`/api/alarms/${alarmId}/dispatch-facilio`, { method: 'POST' });
    const data = await res.json();
    alert(`Successfully dispatched to Facilio CAFM!\nGenerated Ticket ID: ${data.ticketId}\nAssigned Group: Rapid Response`);
    fetchOverviewData();
  } catch (err) {
    alert('Error dispatching to Facilio: ' + err.message);
  }
}

async function testFacilioConnection() {
  try {
    const res = await fetch('/api/facilio/test-connection', { method: 'POST' });
    const data = await res.json();
    alert(`Facilio Connection Status: ${data.status}\nEndpoint: ${data.baseUrl}\nLatency: ${data.latencyMs}ms\nMessage: ${data.message}`);
  } catch (err) {
    alert('Connection test failed: ' + err.message);
  }
}

async function saveFacilioConfig() {
  const cfg = {
    baseUrl: document.getElementById('fclBaseUrl').value,
    orgId: document.getElementById('fclOrgId').value,
    apiKey: document.getElementById('fclApiKey').value,
    siteId: document.getElementById('fclSiteId').value,
    autoDispatchOnCritical: document.getElementById('fclAutoDispatch').checked
  };

  try {
    await fetch('/api/facilio/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cfg)
    });
    alert('Facilio CAFM integration settings saved successfully!');
  } catch (err) {
    alert('Failed saving config: ' + err.message);
  }
}

async function testPingGateway(gwId) {
  try {
    const res = await fetch(`/api/gateways/${gwId}/ping`, { method: 'POST' });
    const data = await res.json();
    alert(`Ping Success!\n${data.message}\nRoundtrip Latency: ${data.latencyMs}ms`);
    fetchOverviewData();
  } catch (err) {
    alert('Ping failed: ' + err.message);
  }
}

// --- Modal Handlers ---
function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.add('active');
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.remove('active');
}

function openAddAssetModal() {
  // Populate Gateways dropdown
  const gwSelect = document.getElementById('inAssetGateway');
  if (gwSelect) {
    gwSelect.innerHTML = state.gateways.map(g => `<option value="${g.id}">${g.name} (${g.protocol})</option>`).join('');
  }

  // Populate dynamic custom fields for ASSET
  const customContainer = document.getElementById('assetCustomFieldsInputs');
  const assetFields = state.customFields.filter(f => f.entity === 'ASSET');
  if (customContainer) {
    if (assetFields.length === 0) {
      customContainer.innerHTML = `<span style="font-size:0.75rem; color:var(--text-muted);">No custom asset fields configured.</span>`;
    } else {
      customContainer.innerHTML = assetFields.map(f => `
        <div class="form-group">
          <label class="form-label">${f.label} ${f.required ? '*' : ''}</label>
          <input type="${f.type === 'number' ? 'number' : (f.type === 'date' ? 'date' : 'text')}" 
                 class="form-input" id="cf_in_${f.key}" value="${f.defaultValue || ''}">
        </div>
      `).join('');
    }
  }

  openModal('modalAddAsset');
}

async function submitSaveAsset() {
  const name = document.getElementById('inAssetName').value;
  const tag = document.getElementById('inAssetTag').value;
  const category = document.getElementById('inAssetCategory').value;
  const criticality = document.getElementById('inAssetCriticality').value;
  const location = document.getElementById('inAssetLocation').value;
  const gatewayId = document.getElementById('inAssetGateway').value;

  if (!name || !tag) {
    alert('Please enter Asset Name and Asset Tag.');
    return;
  }

  // Gather custom fields
  const customFields = {};
  state.customFields.filter(f => f.entity === 'ASSET').forEach(f => {
    const el = document.getElementById(`cf_in_${f.key}`);
    if (el) customFields[f.key] = el.value;
  });

  try {
    const res = await fetch('/api/assets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, tag, category, criticality, location, gatewayId, customFields })
    });
    const created = await res.json();
    closeModal('modalAddAsset');
    alert(`Asset "${created.name}" created and configured with default sensor loop!`);
    loadInitialData();
  } catch (err) {
    alert('Failed creating asset: ' + err.message);
  }
}

function openAddSensorModal(assetId) {
  document.getElementById('inSensorAssetId').value = assetId;
  openModal('modalAddSensor');
}

function autoFillSensorUnit(type) {
  const unitInput = document.getElementById('inSensorUnit');
  const warnInput = document.getElementById('inSensorWarnHigh');
  const critInput = document.getElementById('inSensorCritHigh');

  if (type === 'temperature') { unitInput.value = '°C'; warnInput.value = '45.0'; critInput.value = '60.0'; }
  else if (type === 'vibration') { unitInput.value = 'mm/s'; warnInput.value = '4.5'; critInput.value = '7.0'; }
  else if (type === 'pressure') { unitInput.value = 'bar'; warnInput.value = '16.0'; critInput.value = '19.0'; }
  else if (type === 'current') { unitInput.value = 'A'; warnInput.value = '250.0'; critInput.value = '320.0'; }
  else if (type === 'humidity') { unitInput.value = '%RH'; warnInput.value = '65.0'; critInput.value = '80.0'; }
  else if (type === 'flow') { unitInput.value = 'm³/h'; warnInput.value = '120.0'; critInput.value = '150.0'; }
}

async function submitSaveSensor() {
  const assetId = document.getElementById('inSensorAssetId').value;
  const name = document.getElementById('inSensorName').value;
  const type = document.getElementById('inSensorType').value;
  const unit = document.getElementById('inSensorUnit').value;
  const warningHigh = document.getElementById('inSensorWarnHigh').value;
  const criticalHigh = document.getElementById('inSensorCritHigh').value;

  if (!name) {
    alert('Please specify Sensor Name.');
    return;
  }

  try {
    await fetch(`/api/assets/${assetId}/sensors`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, type, unit, warningHigh, criticalHigh })
    });
    closeModal('modalAddSensor');
    alert(`Sensor attached successfully to ${assetId}!`);
    loadInitialData();
  } catch (err) {
    alert('Failed attaching sensor: ' + err.message);
  }
}

function openAddGatewayModal() {
  openModal('modalAddGateway');
}

async function submitSaveGateway() {
  const name = document.getElementById('inGwName').value;
  const model = document.getElementById('inGwModel').value;
  const protocol = document.getElementById('inGwProtocol').value;
  const ip = document.getElementById('inGwIp').value;
  const location = document.getElementById('inGwLocation').value;

  if (!name) {
    alert('Please enter Gateway Name.');
    return;
  }

  try {
    const res = await fetch('/api/gateways', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, model, protocol, ip, location })
    });
    const created = await res.json();
    closeModal('modalAddGateway');
    alert(`Gateway "${created.name}" registered successfully!\nAPI Key: ${created.apiKey}`);
    loadInitialData();
  } catch (err) {
    alert('Failed registering gateway: ' + err.message);
  }
}

function openAddCustomFieldModal() {
  openModal('modalAddCustomField');
}

async function submitSaveCustomField() {
  const entity = document.getElementById('inCfEntity').value;
  const label = document.getElementById('inCfLabel').value;
  const type = document.getElementById('inCfType').value;
  const defaultValue = document.getElementById('inCfDefault').value;

  if (!label) {
    alert('Please enter Field Label.');
    return;
  }

  try {
    await fetch('/api/custom-fields', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ entity, label, type, defaultValue })
    });
    closeModal('modalAddCustomField');
    alert(`Custom field "${label}" added to ${entity} schema!`);
    loadInitialData();
  } catch (err) {
    alert('Failed adding custom field: ' + err.message);
  }
}

async function deleteCustomField(id) {
  if (!confirm('Are you sure you want to delete this custom field?')) return;
  try {
    await fetch(`/api/custom-fields/${id}`, { method: 'DELETE' });
    renderCustomFieldsTable();
  } catch (err) {
    alert('Failed deleting custom field: ' + err.message);
  }
}

async function deleteAsset(id) {
  if (!confirm(`Are you sure you want to remove asset ${id}?`)) return;
  try {
    await fetch(`/api/assets/${id}`, { method: 'DELETE' });
    loadInitialData();
  } catch (err) {
    alert('Failed deleting asset: ' + err.message);
  }
}

async function deleteGateway(id) {
  if (!confirm(`Are you sure you want to delete gateway ${id}?`)) return;
  try {
    await fetch(`/api/gateways/${id}`, { method: 'DELETE' });
    loadInitialData();
  } catch (err) {
    alert('Failed deleting gateway: ' + err.message);
  }
}

function inspectFacilioPayload(logId) {
  const log = state.facilioLogs.find(l => l.id === logId);
  if (!log) return;
  alert(`Facilio API Dispatch Payload [${log.facilioTicketId}]:\n\nRequest:\n${JSON.stringify(log.requestPayload, null, 2)}\n\nResponse:\n${JSON.stringify(log.responsePayload, null, 2)}`);
}

function inspectAsset(assetId) {
  const asset = state.assets.find(a => a.id === assetId);
  if (!asset) return;
  state.selectedTrendAssetId = assetId;
  const sel = document.getElementById('trendAssetSelect');
  if (sel) sel.value = assetId;
  renderTelemetryChart();
  alert(`Asset Inspected: ${asset.name}\nTag: ${asset.tag}\nStatus: ${asset.status}\nSensors: ${asset.sensors.length}\nStateflow State: ${asset.stateflowState}`);
}

function promptCalibrateSensor(assetId, sensorId) {
  const newWarn = prompt('Enter new Warning High limit:');
  const newCrit = prompt('Enter new Critical High limit:');
  if (!newWarn && !newCrit) return;

  const asset = state.assets.find(a => a.id === assetId);
  if (!asset) return;
  const sensor = asset.sensors.find(s => s.id === sensorId);
  if (!sensor) return;

  if (newWarn) sensor.warningHigh = Number(newWarn);
  if (newCrit) sensor.criticalHigh = Number(newCrit);

  fetch(`/api/assets/${assetId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(asset)
  }).then(() => {
    alert('Sensor threshold calibrated successfully!');
    fetchOverviewData();
  });
}

// --- Mobile View Companion Logic ---
function openMobileSimulator() {
  openModal('modalMobileSimulator');
  renderMobileView('home');
}

function renderMobileView(tab) {
  state.mobileActiveTab = tab;
  const body = document.getElementById('mobileScreenBody');
  if (!body) return;

  if (tab === 'home') {
    body.innerHTML = `
      <div style="font-size:0.75rem; font-weight:700; color:var(--text-muted); text-transform:uppercase; margin-bottom:8px;">
        Field Asset Telemetry
      </div>
      ${state.assets.map(a => `
        <div style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:10px; margin-bottom:8px;">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <div style="font-weight:700; font-size:0.85rem;">${a.name}</div>
            <span class="status-badge ${a.status}" style="font-size:0.65rem;">${a.status}</span>
          </div>
          <div style="font-size:0.7rem; color:var(--text-muted); margin-bottom:6px;">${a.tag} &bull; ${a.location}</div>
          <div style="display:flex; flex-direction:column; gap:4px;">
            ${(a.sensors || []).map(s => `
              <div style="display:flex; justify-content:space-between; font-size:0.75rem; background:var(--bg-input); padding:3px 6px; border-radius:4px;">
                <span>${s.name}</span>
                <strong style="color:${s.status === 'CRITICAL' ? '#F87171' : 'var(--text-primary)'};">${s.currentValue} ${s.unit}</strong>
              </div>
            `).join('')}
          </div>
        </div>
      `).join('')}
    `;
  } else if (tab === 'scanner') {
    body.innerHTML = `
      <div style="text-align:center; padding:20px 10px;">
        <div style="width:160px; height:160px; border:2px dashed #3B82F6; border-radius:12px; margin:0 auto 16px; display:flex; flex-direction:column; align-items:center; justify-content:center; background:rgba(59,130,246,0.08);">
          <i data-lucide="scan" style="width:48px; height:48px; color:#60A5FA;"></i>
          <span style="font-size:0.7rem; color:#60A5FA; margin-top:6px;">Align Asset QR Code</span>
        </div>
        <button class="top-btn primary" style="width:100%; justify-content:center; font-size:0.8rem;" onclick="simulateQrScan('AST-101')">
          <i data-lucide="qr-code"></i> Simulate Scan (Chiller 01)
        </button>
      </div>
    `;
  } else if (tab === 'alarms') {
    body.innerHTML = `
      <div style="font-size:0.75rem; font-weight:700; color:#F87171; text-transform:uppercase; margin-bottom:8px;">
        Active Field Alarms
      </div>
      ${state.alarms.length === 0 ? `
        <div style="text-align:center; padding:30px 10px; color:var(--text-muted); font-size:0.8rem;">No active alarms</div>
      ` : state.alarms.map(alm => `
        <div style="background:var(--bg-card); border-left:3px solid #F87171; border-radius:var(--radius-sm); padding:10px; margin-bottom:8px;">
          <div style="font-weight:700; font-size:0.8rem; color:#F87171;">${alm.severity}: ${alm.assetName}</div>
          <div style="font-size:0.72rem; color:var(--text-secondary); margin:4px 0;">${alm.message}</div>
          <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px;">
            <button class="top-btn" style="padding:2px 8px; font-size:0.7rem;" onclick="acknowledgeAlarm('${alm.id}')">Acknowledge</button>
            ${!alm.facilioTicketId ? `<button class="top-btn primary" style="padding:2px 8px; font-size:0.7rem;" onclick="dispatchAlarmToFacilio('${alm.id}')">Dispatch WO</button>` : `<span style="font-size:0.7rem; color:#60A5FA; font-weight:700;">${alm.facilioTicketId}</span>`}
          </div>
        </div>
      `).join('')}
    `;
  } else if (tab === 'facilio') {
    body.innerHTML = `
      <div style="font-size:0.75rem; font-weight:700; color:#60A5FA; text-transform:uppercase; margin-bottom:8px;">
        Facilio CAFM Work Orders
      </div>
      ${state.facilioLogs.map(l => `
        <div style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:10px; margin-bottom:8px;">
          <div style="display:flex; justify-content:space-between;">
            <span style="font-weight:800; color:#60A5FA; font-size:0.8rem;">${l.facilioTicketId}</span>
            <span class="status-badge HEALTHY" style="font-size:0.6rem;">${l.status}</span>
          </div>
          <div style="font-size:0.75rem; color:var(--text-primary); margin-top:4px;">${l.assetName}</div>
          <div style="font-size:0.68rem; color:var(--text-muted); margin-top:2px;">Dispatched: ${new Date(l.timestamp).toLocaleTimeString()}</div>
        </div>
      `).join('')}
    `;
  }

  if (window.lucide) lucide.createIcons();
}

function updateMobileScreen() {
  if (state.mobileActiveTab) renderMobileView(state.mobileActiveTab);
}

function simulateQrScan(assetId) {
  const asset = state.assets.find(a => a.id === assetId);
  if (!asset) return;
  alert(`QR Tag Verified: ${asset.customFields?.qrTag || 'QR-BKY-CH01'}\nAsset: ${asset.name}\nLocation: ${asset.location}\nAll sensors operational.`);
  renderMobileView('home');
}

// Helpers
function getSensorIcon(type) {
  if (type === 'temperature') return 'thermometer';
  if (type === 'vibration') return 'activity';
  if (type === 'pressure') return 'gauge';
  if (type === 'current') return 'zap';
  if (type === 'humidity') return 'droplets';
  if (type === 'flow') return 'waves';
  return 'cpu';
}
